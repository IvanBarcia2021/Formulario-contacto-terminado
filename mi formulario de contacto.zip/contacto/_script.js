  var respuesta=document.getElementById('respuesta');
  var btn=document.getElementById('btn');
  var regresar=document.getElementById('regresar');
  var resultado=document.getElementById('resultado');
  //var miboton;
  function mostrar(){
    resultado.innerHTML=``;
   

  }
 // `
    btn.addEventListener('click',()=>{
     
      var nombre=document.getElementById('nombre').value;
      var correo=document.getElementById('correo').value;
      var telefono=document.getElementById('telefono').value;
      var mensaje=document.getElementById('mensaje').value;
      var dni=document.getElementById('dni').value;
      var datos={
      "nombre":nombre,
      "correo":correo,
      "telefono":telefono,
      "mensaje":mensaje,
      "dni":dni,
  }
  
   $.ajax({
    url:'_insert.php',
    type:'POST',
    data:datos,
  })
  .done(function(res){
  resultado.innerHTML=res;
  
   respuesta.innerHTML=`Para enviar un nuevo mensaje, volve a cargar el formulario`;
 
  })
  .fail(function(){
    console.log("error")
  })
  .always(function(){
    console.log("complete");
  })
    })
