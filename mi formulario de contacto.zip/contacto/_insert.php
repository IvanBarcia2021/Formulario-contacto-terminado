<?php
$serverName="DESKTOP-Q0MMTIN\MSSQLSERVER01";
$connectionInfo = array( "Database"=>"formulario", "UID"=>"sa", "PWD"=>"SA");
$conn = sqlsrv_connect( $serverName, $connectionInfo);
/*if( $conn ) {
    echo "Conexión establecida.<br />";
}else{
    echo "Conexión no se pudo establecer.<br />";
    die( print_r( sqlsrv_errors(), true));
}*/
$nombre=$_POST['nombre'];
$correo=$_POST['correo'];
$mensaje=$_POST['mensaje'];
$telefono=$_POST['telefono'];
$dni=$_POST['dni'];
$query="INSERT INTO mensajes(dni,nombre,telefono,correo,mensaje) VALUES('$dni','$nombre','$telefono','$correo','$mensaje')";

//echo "su nombre es".$nombre."su correo es".$correo."su mensaje es".$mensaje."y su telefono es ".$telefono;
$res=sqlsrv_prepare($conn,$query);


if(sqlsrv_execute($res)){
  echo "Datos ingresados correctamente";
}
else{
  echo "Error al ingresar los datos, intentalo nuevamente";
}

?>